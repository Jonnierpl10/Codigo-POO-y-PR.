
package ec.edu.espoch.logaritmicaspr;

import ec.edu.espoch.logartimicaspr.Vista.Vista;
import es.esu.espoch.logaritmicaspr.modelo.LogaritmosConBase;
import es.esu.espoch.logaritmicaspr.modelo.LogaritmosNaturales;

/**
 * Jonnier
 */
public class LogaritmicasPR {

    public static void main(String[] args) {
        LogaritmosConBase modeloConBase = new LogaritmosConBase();
        LogaritmosNaturales modeloNaturales = new LogaritmosNaturales();
        Vista objVista = new Vista(modeloConBase, modeloNaturales);
        objVista.setLocationRelativeTo(null);
        objVista.setVisible(true);
    }
}
