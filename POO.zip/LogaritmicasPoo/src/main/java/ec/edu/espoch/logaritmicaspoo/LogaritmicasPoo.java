package ec.edu.espoch.logaritmicaspoo;

import ec.edu.espoch.logaritmicaspoo.vista.Interfaz;

public class LogaritmicasPoo {

    public static void main(String[] args) {
        Interfaz objInterfaz = new Interfaz();
        objInterfaz.setVisible(true);
        objInterfaz.setLocationRelativeTo(null);
    }
}
