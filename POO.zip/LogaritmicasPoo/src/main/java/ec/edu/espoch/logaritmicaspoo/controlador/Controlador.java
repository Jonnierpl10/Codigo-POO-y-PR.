package ec.edu.espoch.logaritmicaspoo.controlador;

import ec.edu.espoch.logaritmicaspoo.modelo.LogaritmosConBase;
import ec.edu.espoch.logaritmicaspoo.modelo.LogaritmosNaturales;
import ec.edu.espoch.logaritmicaspoo.vista.Interfaz;

public class Controlador {
    private Interfaz vista;
    private LogaritmosConBase logBase;
    private LogaritmosNaturales logNat;

    public Controlador(Interfaz vista) {
        this.vista = vista;
        this.logBase = new LogaritmosConBase();
        this.logNat = new LogaritmosNaturales();
    }
    
    public void accionBoton(){
        long startTime = System.nanoTime();
        String funcion = String.valueOf(this.vista.getIngresoValores());
        if (funcion.contains("log")) {
            this.vista.setTxtResultado(this.logBase.resolver(funcion));
        } else if(funcion.contains("ln")){
            this.vista.setTxtResultado(this.logNat.resolver(funcion));
        }
        long endTime = System.nanoTime();
        long tiempoDeEjecucion = endTime - startTime;
        System.out.println("Tiempo de ejecución: " + tiempoDeEjecucion + " ns");
    }
}
 